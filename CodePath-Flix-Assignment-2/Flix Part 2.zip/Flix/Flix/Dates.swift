//
//  Dates.swift
//  Flix
//
//  Created by Griffin Davidson on 3/4/22.
//

import Foundation
class Dates
{
    
    static let shared = Dates()
    
    public func formatDate(_ string: String) -> String
    {
        let fmt = DateFormatter()
        fmt.locale = Locale(identifier: "en_US_POSIX")
        fmt.dateFormat = "yyyy-MM-dd"

        //first, convert string to Date
        let date = fmt.date(from: string)!

        //then convert Date back to String in a different format
        fmt.dateFormat = "MMMM d, yyyy"
        return fmt.string(from: date)
    }
}
