//
//  MovieCollectionViewCell.swift
//  Flix
//
//  Created by Griffin Davidson on 3/4/22.
//

import UIKit
import AlamofireImage

class MovieCollectionViewCell: UICollectionViewCell
{
    
    @IBOutlet weak var moviePosterImage: UIImageView!
    
    let baseURL = "https://image.tmdb.org/t/p/w185"
    
    func configure(with movie: Movie)
    {
        moviePosterImage.af.setImage(withURL: URL(string: baseURL + movie.posterURL)!)
    }
}
