//
//  Movie.swift
//  Flix
//
//  Created by Griffin Davidson on 2/20/22.
//

import Foundation

struct Movie: Codable
{
    enum CodingKeys: String, CodingKey
    {
        case id
        case title
        case description = "overview"
        case posterURL = "poster_path"
        case year = "release_year"
    }
    
    let id: Int
    let title: String
    let description: String
    let posterURL: String
    let year: String
}
