//
//  MovieDetais.swift
//  Flix
//
//  Created by Griffin Davidson on 2/28/22.
//

import UIKit
import AlamofireImage

class MovieDetailsViewController: UIViewController
{
    
    let baseURL = "https://image.tmdb.org/t/p/w185"
    
    @IBOutlet weak var movieDetailBackdropImageView: UIImageView!
    @IBOutlet weak var movieDetailPosterImage: UIImageView!
    @IBOutlet weak var movieDetailDateLabel: UILabel!
    @IBOutlet weak var movieDetailAdultLabel: UILabel!
    @IBOutlet weak var movieDetailOverviewLabel: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func configure(with id: Int)
    {
        MovieService.shared.fetchMovieDetail(id: id) { [weak self] movieDetail in
            self?.navigationItem.title = movieDetail?.title
            self?.movieDetailBackdropImageView.af.setImage(withURL: URL(string: self!.baseURL + movieDetail!.backdrop)!)
            self?.movieDetailPosterImage.af.setImage(withURL: URL(string: self!.baseURL + movieDetail!.posterURL)!)
            
            self?.movieDetailDateLabel.text = Dates.shared.formatDate(movieDetail!.release)
            
            if movieDetail!.adultRating
            {
                self?.movieDetailAdultLabel.text = "Yes"
            }
            else
            {
                self?.movieDetailAdultLabel.text = "No"
            }
            
            self?.movieDetailOverviewLabel.text = movieDetail!.overview
            
            
            
            
        }
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
}
