//
//  MovieGridViewController.swift
//  Flix
//
//  Created by Griffin Davidson on 3/4/22.
//

import UIKit

class MovieCollectionViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate
{
    
    @IBOutlet weak var movieGridView: UICollectionView!
    
    private var movies = [Movie]()
    {
        didSet
        {
            movieGridView.reloadData()
        }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.movieGridView.dataSource = self
        self.movieGridView.delegate = self
        
        let layout = movieGridView.collectionViewLayout as! UICollectionViewFlowLayout
        
        layout.minimumLineSpacing = 2
        layout.minimumInteritemSpacing = 2
        
        let width = (view.frame.size.width - layout.minimumInteritemSpacing * 2) / 2
        layout.itemSize = CGSize(width: width, height: width * 3 / 2)
        
        MovieService.shared.fetchMovies(
        { movies in
            self.movies = movies
        })
        
        tabBarController?.title = "Flix"
        
        navigationItem.title = "Flix"
        navigationItem.largeTitleDisplayMode = .automatic

        // Do any additional setup after loading the view.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MovieCollectionViewCell", for: indexPath) as? MovieCollectionViewCell
        else
        {
            return UICollectionViewCell()
        }
        cell.configure(with: movies[indexPath.row])
        
        return cell
    }
    
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation

}
