//
//  MovieDetail.swift
//  Flix
//
//  Created by Griffin Davidson on 2/28/22.
//

import Foundation

struct MovieDetail: Codable
{
    enum CodingKeys: String, CodingKey
    {
        case id
        case title
        case overview
        case posterURL = "poster_path"
        case release = "release_date"
        case backdrop = "backdrop_path"
        case adultRating = "adult"
    }
    
    let id: Int
    let title: String
    let overview: String
    let posterURL: String //poster_path
    let release: String //release_date
    let backdrop: String //backdrop_path
    let adultRating: Bool //adult
}
