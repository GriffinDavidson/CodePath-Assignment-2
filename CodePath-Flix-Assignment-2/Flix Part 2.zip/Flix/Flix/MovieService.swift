//
//  MovieService.swift
//  Flix
//
//  Created by Griffin Davidson on 2/20/22.
//

import Foundation

class MovieService
{
    static let shared = MovieService()
    
    let url = "https://api.themoviedb.org/3/movie/now_playing?api_key="
    let apiKey = "7449dcb61a9a45f28659182b2de515fd"
    let accessToken = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI3NDQ5ZGNiNjFhOWE0NWYyODY1OTE4MmIyZGU1MTVmZCIsInN1YiI6IjYyMTQ1NDlhMzgzZGYyMDA0MjQ1NzE1MCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ._3VNs1H_6gj_LRjVWU803bmJ8nDNuzLvu8urDIx1cYU"
    let session = URLSession(configuration: .default,
                             delegate: nil,
                             delegateQueue: .main)
    
    func fetchMovies(_ completion: @escaping(([Movie]) -> Void))
    {
        var request = URLRequest(url: URL(string: url + apiKey)!, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 10)
        request.httpMethod = "GET"
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        request.addValue("application/iOS;charset=utf-8", forHTTPHeaderField: "Content-Type")
        let task = session.dataTask(with: request)
        { data, response, error in
            guard error == nil else
            {
                print("Error Detected!")
                print("\(error?.localizedDescription ?? "Unable to parse error")")
                return
            }
            
            guard let data = data else
            {
                print("No data detected!")
                return
            }
            print("Testing Console...")
            
            let dataDictionary = try! JSONSerialization.jsonObject(with: data, options: []) as! [String: Any]
            let movieRawData = dataDictionary["results"] as! [[String: Any]]
            var movies = [Movie]()
            for rawData in movieRawData
            {
                let movie = Movie(
                    id: rawData["id"] as! Int,
                    title: rawData["title"] as! String,
                    description: rawData["overview"] as! String,
                    posterURL: rawData["poster_path"] as! String,
                    year: rawData["release_date"] as! String)
                movies.append(movie)
                
                
            }
    
            completion(movies)
        }
        task.resume()
    }
    
    func fetchMovieDetail(id: Int, completion: @escaping (MovieDetail?) -> Void)
    {
        let url3 = URL(string: "https://api.themoviedb.org/3/movie/\(id)")!
        
        var request = URLRequest(url: url3, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 10)
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        let task = session.dataTask(with: request)
        { data, response, error in
            if let error = error
            {
                print(error.localizedDescription)
            }
            else if let data = data
            {
                let decoder = JSONDecoder()
                let movieDetail = try? decoder.decode(MovieDetail.self, from: data)
                completion(movieDetail)
            }
            
        }
        task.resume()
    }
    
}
